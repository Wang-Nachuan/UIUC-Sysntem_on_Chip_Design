#ifndef __MULTIPLY__H_
#define __MULTIPLY__H_

void multiply_partB_1(int A[100][100], int B[100][100], int C[100][100], int mA, int nA, int mB, int nB, int mC, int nC);
void multiply_partB_2(int A[100][100], int B[100][100], int C[100][100], int mA, int nA, int mB, int nB, int mC, int nC);

// Test

void multiply_key(int A[100][100], int B[100][100], int C[100][100], int mA, int nA, int mB, int nB, int mC, int nC);

#endif
